#!/bin/bash

read -p "Where do you want to install Sniper? [Example: /home/<Your Account>/Documents] " DEST_DIR

INSTALL_DIR="installation_files/*"
TMP="tmp"

if [ -d $TMP ]; then
	rm -rf $TMP
fi

mkdir $TMP

for file in $INSTALL_DIR; do
	tar -xvzf $file -C $TMP
done

FILE_RM=$(find $TMP -maxdepth 1 -type d -name "*pin2")
rm -rf $FILE_RM

SNIPER=$(find $TMP -maxdepth 1 -type d -name "sniper*")
TARGET=$SNIPER"/pin_kit"

TMP="tmp/*"

for file in $TMP; do
	# Move pin tool into Sniper
	if [ ${file:4:3} = "pin" ]; then
		mv $file $TARGET
	fi
done

# Install Dependencies
sudo apt-get install zlib1g-dev
sudo apt-get install libbz2-dev
sudo apt-get install build-essential
sudo apt-get install python
sudo apt-get install libsqlite3-dev
sudo apt-get install libboost-dev
sudo apt-get install m4
sudo apt-get install xsltproc
sudo apt-get install libx11-dev
sudo apt-get install libxext-dev
sudo apt-get install libxt-dev
sudo apt-get install libxmu-dev
sudo apt-get install libxi-dev
sudo apt-get install gfortran
sudo apt-get autoremove
sudo apt-get update
sudo apt-get upgrade
sudo apt-get dist-upgrade

mv $SNIPER $DEST_DIR
BUILD_DIR=$(find $DEST_DIR -maxdepth 1 -type d -name "sniper*")
make -C $BUILD_DIR
rm -rf tmp/
